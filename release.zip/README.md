# CombatCursorContainment

A FFXIV Dalamud plugin to automatically lock your cursor to the game window during combat, with options to do so except when:
- Dead
- Not in a duty
- In a cutscene
- Weapon is sheathed
- On a mount
- On a crafter/gatherer class
